//
//  AlertViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

class AlertViewController: UIViewController {
    @IBOutlet weak var viewbg: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    
    var alertTiel: String = ""
    var alertMessatge: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        
        lblTitle.text = alertTiel
        lblMessage.text = alertMessatge
        
        viewbg.layer.cornerRadius = 10
        btnBack.layer.cornerRadius = 10
    }
    
    @IBAction func btnBack(_ sender: Any) {
        self.dismiss(animated: true)
    }
}
