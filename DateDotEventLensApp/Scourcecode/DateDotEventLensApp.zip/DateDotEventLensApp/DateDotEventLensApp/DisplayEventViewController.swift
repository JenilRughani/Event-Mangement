//
//  DisplayEventViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

struct EventView: Codable {
    var title: String
    var subTitle: String
    var place: String
    var message: String
    var date: String
    var time: String
}

var arrOfEvent: [EventView] = []

class EventCell: UICollectionViewCell {
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var viewState: UIView!
    @IBOutlet weak var btnShare: UIButton!
    @IBOutlet weak var lblstateName: UILabel!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSubTitle: UILabel!
    @IBOutlet weak var lblPlace: UILabel!
    @IBOutlet weak var lbldate: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblMessage: UILabel!
    @IBOutlet weak var btnMore: UIButton!
   
    var action: (()->()) = {}
    var actionShare: (()->()) = {}
    
    @IBAction func btnMore(_ sender: UIButton) {
        action()
    }
    
    @IBAction func btnShare(_ sender: UIButton) {
        actionShare()
    }
}

class DisplayEventViewController: UIViewController {
    @IBOutlet weak var collectionVoew: UICollectionView!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let data = UserDefaults.standard.data(forKey: "arrOfEvent") {
            arrOfEvent = try! PropertyListDecoder().decode([EventView].self, from: data)
            collectionVoew.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Events"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        let add = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            add.setImage(UIImage(systemName: "plus"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        add.setTitle("Event", for: .normal)
        add.tintColor = .black
        add.setTitleColor(.black, for: .normal)
        add.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        add.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        add.addTarget(self, action: #selector(rightBtnAction(_:)), for: .touchUpInside)
        let item = UIBarButtonItem(customView: add)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
        
        if let data = UserDefaults.standard.data(forKey: "arrOfEvent") {
            arrOfEvent = try! PropertyListDecoder().decode([EventView].self, from: data)
        }
        
        collectionVoew.delegate = self
        collectionVoew.dataSource = self
    }
    
    @objc func rightBtnAction(_ sender: UIButton) {
        let add = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddEventViewController") as! AddEventViewController
        self.navigationController?.pushViewController(add, animated: true)
    }
}

//MARK: - CollectionView Delegate and DataSource Methods
extension DisplayEventViewController  : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        arrOfEvent.isEmpty ? collectionView.setEmptyDataImage() : collectionView.restoreEmptyDataImage()
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrOfEvent.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "EventCell", for: indexPath) as! EventCell
        
        viewsShadowApply(cell.viewMain)
        cell.lbldate.text = arrOfEvent[indexPath.row].date
        cell.lblTime.text = arrOfEvent[indexPath.row].time
        cell.lblPlace.text = arrOfEvent[indexPath.row].place
        cell.lblTitle.text = arrOfEvent[indexPath.row].title
        cell.lblMessage.text = arrOfEvent[indexPath.row].message
        cell.lblSubTitle.text = arrOfEvent[indexPath.row].subTitle
        
        cell.viewState.layer.cornerRadius = 10
        cell.btnMore.layer.cornerRadius = 10
        
        cell.img.image = generateQRCode(from: arrOfEvent[indexPath.row].message)
        
        cell.action = {
            let details = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
            details.strDate = arrOfEvent[indexPath.row].date
            details.strPlace = arrOfEvent[indexPath.row].place
            details.strTitle = arrOfEvent[indexPath.row].title
            details.strMessage = arrOfEvent[indexPath.row].message
            self.navigationController?.pushViewController(details, animated: true)
        }
        
        cell.actionShare = {
            arrOfStarEvent.append(arrOfEvent[indexPath.row])
            
            if let data = try? PropertyListEncoder().encode(arrOfStarEvent) {
                UserDefaults.standard.set(data, forKey: "arrOfStarEvent")
            }
            
            if #available(iOS 13.0, *) {
                cell.btnShare.setImage(UIImage(systemName: "star.fill"), for: .normal)
                cell.btnShare.tintColor = UIColor.systemYellow
            } else {
                // Fallback on earlier versions
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                arrOfEvent.remove(at: indexPath.row)
                
                if let data = try? PropertyListEncoder().encode(arrOfEvent) {
                    UserDefaults.standard.set(data, forKey: "arrOfEvent")
                }
                
                self.collectionVoew.reloadData()
            }
        }
        
        return cell
    }
    
    func generateQRCode(from string: String) -> UIImage? {
        // Convert the string to data
        let data = string.data(using: String.Encoding.ascii)
        
        // Create a CIFilter for QR code generation
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            filter.setValue("Q", forKey: "inputCorrectionLevel") // Error correction level (L, M, Q, H)
            
            // Retrieve the generated QR code image
            guard let qrCodeImage = filter.outputImage else { return nil }
            
            // Scale the QR code for proper display
            let scaledQRCode = qrCodeImage.transformed(by: CGAffineTransform(scaleX: 10, y: 10))
            
            // Convert CIImage to UIImage for display
            return UIImage(ciImage: scaledQRCode)
        }
        
        return nil
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.bounds.width/1.2)-2, height: (collectionView.bounds.height/1)-2)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        eventactionSheet(title: "Action", message: nil, defaultTitle1: "Update", defaultTitle2: "Delete", destructiveTitle: "cancle") {
            let details = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddEventViewController") as! AddEventViewController
            details.isUpdate = true
            details.index = indexPath.row
            self.navigationController?.pushViewController(details, animated: true)
        } action2: {
            arrOfEvent.remove(at: indexPath.row)
            if let data = try? PropertyListEncoder().encode(arrOfEvent) {
                UserDefaults.standard.set(data, forKey: "arrOfEvent")
            }
            self.collectionVoew.reloadData()
        }
    }
}
