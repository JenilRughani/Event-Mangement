//
//  StarTaskViewController.swift
//  DateDotEventLensApp
//
//   
//

import UIKit

class StarCell: UITableViewCell {
    @IBOutlet weak var viewbg: UIView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblMEssage: UILabel!
}

class StarTaskViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let data = UserDefaults.standard.data(forKey: "arrOfStarTask") {
            arrOfStarTask = try! PropertyListDecoder().decode([TaskView].self, from: data)
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)
        
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            filter.setValue("Q", forKey: "inputCorrectionLevel")
            
            guard let qrCodeImage = filter.outputImage else { return nil }
            
            let scaledQRCode = qrCodeImage.transformed(by: CGAffineTransform(scaleX: 10, y: 10))
            
            return UIImage(ciImage: scaledQRCode)
        }
        
        return nil
    }

}

extension StarTaskViewController : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        arrOfStarTask.isEmpty ? tableView.setEmptyDataImage() : tableView.restoreEmptyDataImage()
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrOfStarTask.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StarCell", for: indexPath) as! StarCell
        
        viewsShadowApply(cell.viewbg)
        cell.lblTitle.text = arrOfStarTask[indexPath.row].title
        cell.lblMEssage.text = arrOfStarTask[indexPath.row].message
        cell.img.image = generateQRCode(from: arrOfStarTask[indexPath.row].message)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let details = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        details.strPlace = arrOfStarTask[indexPath.row].place
        details.strDate =  arrOfStarTask[indexPath.row].currentDate
        details.strTitle = arrOfStarTask[indexPath.row].title
        details.strMessage = arrOfStarTask[indexPath.row].message
        self.navigationController?.pushViewController(details, animated: true)
    }
}
