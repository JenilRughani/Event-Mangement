//
//  CalViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

class CalViewController: UIViewController {
    @IBOutlet weak var lblFirstHeading: UILabel!
    @IBOutlet weak var txtFirst: UITextField!
    @IBOutlet weak var lblSecoundHEading: UILabel!
    @IBOutlet weak var txtSecound: UITextField!
    @IBOutlet weak var viewBG: UIView!
    @IBOutlet weak var lblQue: UILabel!
    @IBOutlet weak var lblAns: UILabel!
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var btnCal: UIButton!
    
    var isAgeCal: Bool = false
    var isconverter: Bool = false
    var arrOfConverter: [String] = ["Kiloeter To Meter", "Meter To Decimeter", "Centimeter To Micrometer"]
    var picker = UIPickerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = isconverter ? "Converter" : isAgeCal ? "Age Calcualator" : "Calculator"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        colorGradient()
        
        if isconverter {
            lblFirstHeading.text = "Enter a value:"
            lblSecoundHEading.text = "Select the converter:"
            txtFirst.placeholder = "00"
            txtSecound.placeholder = "select"
            picker.delegate = self
            picker.dataSource = self
            txtSecound.inputView = picker
            btnCal.setTitle("Converter", for: .normal)
        } else {
            if isAgeCal {
                lblFirstHeading.text = "Enter a first person date:"
                lblSecoundHEading.text = "Enter a seound person date:"
                txtFirst.placeholder = "dd/mm/yyyy"
                txtSecound.placeholder = "dd/mm/yyyy"
                datePickerMethodFirst()
                datePickerMethodSeound()
                btnCal.setTitle("Age Calculator", for: .normal)
            } else {
                lblFirstHeading.text = "Enter a first value:"
                lblSecoundHEading.text = "Enter a seound value:"
                txtFirst.placeholder = "00"
                txtSecound.placeholder = "00"
                btnCal.setTitle("Calculator", for: .normal)
            }
        }
        
        let clear = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            clear.setImage(UIImage(systemName: "multiply.circle.fill"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        clear.setTitle("Clear", for: .normal)
        clear.tintColor = .black
        clear.setTitleColor(.black, for: .normal)
        clear.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        clear.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        clear.addTarget(self, action: #selector(rightBtnAction(_:)), for: .touchUpInside)
        let item = UIBarButtonItem(customView: clear)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
        
        viewBG.isHidden = true
        viewsShadowApply(viewBG)
        viewCornerBottom(view: viewMain)
    }
    
    func datePickerMethodFirst() {
        
        let datePickerView: UIDatePicker        = UIDatePicker()
        
        if #available(iOS 13.4, *) {
            datePickerView.preferredDatePickerStyle = .wheels
        } else {
            // Fallback on earlier versions
        }
        
        datePickerView.datePickerMode           = .date
        
        datePickerView.minimumDate              = Calendar.current.date(byAdding: .year, value: -100, to: Date())
        datePickerView.maximumDate              = Calendar.current.date(byAdding: .year, value: 0, to: Date())
        
        datePickerView.countDownDuration        = 10.0
        
        txtFirst.inputView          = datePickerView
        datePickerView.addTarget(self, action: #selector(datePickerStayleFirst(_:)), for: UIControl.Event.valueChanged)
        
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        txtFirst.inputAccessoryView = toolBar
        
        let donebtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(createBarButtonDone))
        toolBar.setItems([donebtn], animated: true)
        
    }
    
    @objc func datePickerStayleFirst(_ sender: UIDatePicker) {
        let dateFormate                         = DateFormatter()
        dateFormate.dateFormat                  = "dd / MM / yyyy"
        txtFirst.text               = dateFormate.string(from: sender.date)
    }
    
    func datePickerMethodSeound() {
        
        let datePickerView: UIDatePicker        = UIDatePicker()
        
        if #available(iOS 13.4, *) {
            datePickerView.preferredDatePickerStyle = .wheels
        } else {
            // Fallback on earlier versions
        }
        
        datePickerView.datePickerMode           = .date
        
        datePickerView.minimumDate              = Calendar.current.date(byAdding: .year, value: -100, to: Date())
        datePickerView.maximumDate              = Calendar.current.date(byAdding: .year, value: 0, to: Date())
        
        datePickerView.countDownDuration        = 10.0
        
        txtSecound.inputView          = datePickerView
        datePickerView.addTarget(self, action: #selector(datePickerStayleSeound(_:)), for: UIControl.Event.valueChanged)
        
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        txtSecound.inputAccessoryView = toolBar
        
        let donebtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(createBarButtonDone))
        toolBar.setItems([donebtn], animated: true)
        
    }
    
    @objc func datePickerStayleSeound(_ sender: UIDatePicker) {
        let dateFormate                         = DateFormatter()
        dateFormate.dateFormat                  = "dd / MM / yyyy"
        txtSecound.text               = dateFormate.string(from: sender.date)
    }
    
    @objc func createBarButtonDone(){
        self.view.endEditing(true)
    }
    
    @objc func rightBtnAction(_ sender: UIButton) {
        txtFirst.text = ""
        txtSecound.text = ""
        viewBG.isHidden = true
    }
    
    private func converters() -> String {
        
        let value = Double(txtFirst.text!) ?? 0.0
        
        switch txtSecound.text! {
        case arrOfConverter[0]:
            return String(value * 1000)
            
        case arrOfConverter[1]:
            return String(value * 10)
            
        case arrOfConverter[2]:
            return String(value * 10000)
            
        default:
            return ""
        }
    }
    
    private func calculateAgeDifference(from firstDateString: String, to secondDateString: String) -> DateComponents? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        guard let firstDate = dateFormatter.date(from: firstDateString),
              let secondDate = dateFormatter.date(from: secondDateString) else {
            return nil
        }
        
        let calendar = Calendar.current
        let ageDifference = calendar.dateComponents([.year, .month, .day], from: firstDate, to: secondDate)
        
        return ageDifference
    }
    
    @IBAction func btnCal(_ sender: Any) {
        if txtFirst.text!.isEmpty || txtSecound.text!.isEmpty {
            alertVc(message: "Please enter a value in textfiled.")
        } else {
            if isconverter {
                lblAns.text = converters()
                lblQue.text = txtSecound.text!
                self.viewBG.isHidden = false
            } else {
                if isAgeCal {
                    lblQue.text = "\(txtFirst.text!) To \(txtSecound.text!)"
                    if let ageDifference = calculateAgeDifference(from: txtFirst.text!, to: txtSecound.text!) {
                        lblAns.text = "\(ageDifference.year ?? 0) y, \(ageDifference.month ?? 0) m, \(ageDifference.day ?? 0) d"
                    } else {
                        lblAns.text = "Invalid date format"
                        alertVc(message: "Invalid date format")
                    }
                    self.viewBG.isHidden = false
                } else {
                    
                    let first = Double(txtFirst.text!) ?? 0.0
                    let seoun = Double(txtSecound.text!) ?? 0.0
                    
                    actionSheet(title: "Action", message: "Please select the method.", defaultTitle1: "Addition", defaultTitle2: "Subtraction", defaultTitle3: "Multiplication", defaultTitle4: "Division", destructiveTitle: "Cancle") {
                        
                        self.lblQue.text = "\(self.txtFirst.text!) + \(self.txtSecound.text!)"
                        self.lblAns.text = String(first + seoun)
                        self.viewBG.isHidden = false
                        
                    } action2: {
                        
                        self.lblQue.text = "\(self.txtFirst.text!) - \(self.txtSecound.text!)"
                        self.lblAns.text = String(first - seoun)
                        self.viewBG.isHidden = false
                        
                    } action3: {
                        
                        self.lblQue.text = "\(self.txtFirst.text!) * \(self.txtSecound.text!)"
                        self.lblAns.text = String(first * seoun)
                        self.viewBG.isHidden = false
                        
                    } action4: {
                        
                        if first != 0 || seoun != 0 {
                            self.lblQue.text = "\(self.txtFirst.text!) / \(self.txtSecound.text!)"
                            self.lblAns.text = String(first / seoun)
                            self.viewBG.isHidden = false
                        } else
                        {
                            self.alertVc(message: "You are enter the 0, So any number not divied to zero.")
                        }
                    }
                }
            }
        }
    }
}

//MARK: - UIPickerView Delegate methods
extension CalViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrOfConverter.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrOfConverter[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        txtSecound.text = arrOfConverter[row]
    }
}
