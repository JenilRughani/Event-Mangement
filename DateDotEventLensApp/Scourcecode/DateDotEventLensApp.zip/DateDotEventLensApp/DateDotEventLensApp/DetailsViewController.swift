//
//  DetailsViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

class DetailsViewController: UIViewController {
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblPlace: UILabel!
    @IBOutlet weak var lblMEssage: UILabel!
    
    var strTitle: String = ""
    var strDate: String = ""
    var strPlace: String = ""
    var strMessage: String = ""
    private var value : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Details"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        colorGradient()
        
        lblDate.text = strDate
        lblPlace.text = strPlace
        lblTitle.text = strTitle
        lblMEssage.text = strMessage
        
        value = """
\(strDate),
\(strPlace),
\(strTitle),
\(strMessage)
"""
        
        img.image = generateQRCode(from: value)
    }
    
    func generateQRCode(from string: String) -> UIImage? {
        print(string)
        let data = string.data(using: String.Encoding.ascii)
        
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)
            
            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }
        return nil
    }
    
    @IBAction func btnShare(_ sender: Any) {
        let textToShare = [value]
        let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
        activityViewController.excludedActivityTypes = [ UIActivity.ActivityType.airDrop, UIActivity.ActivityType.postToFacebook ]
        self.present(activityViewController, animated: true, completion: nil)
    }
}
