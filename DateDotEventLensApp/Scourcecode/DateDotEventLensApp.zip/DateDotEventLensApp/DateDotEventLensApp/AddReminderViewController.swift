//
//  AddReminderViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

class AddReminderViewController: UIViewController {
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtDate: UITextField!
    @IBOutlet weak var txtMessage: UITextView!
    @IBOutlet weak var viewMain: UIView!
    
    var isBdReminder: Bool = false
    var id: Int = 0
    var bdID: Int = 0
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if let data = UserDefaults.standard.data(forKey: "arrOfReminde") {
            arrOfReminde = try! PropertyListDecoder().decode([ReminderView].self, from: data)
        }
        
        if let data = UserDefaults.standard.data(forKey: "arrOfBdReminde") {
            arrOfBdReminde = try! PropertyListDecoder().decode([ReminderView].self, from: data)
        }
        
        id = UserDefaults.standard.integer(forKey: "id")
        bdID = UserDefaults.standard.integer(forKey: "bdID")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = isBdReminder ? "Add BirthDay" : "Add Reminder"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        colorGradient()
        viewCornerBottom(view: viewMain)
        txtViewBorder(txt: txtMessage)
        
        datePickerMethod()
        
        let clear = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            clear.setImage(UIImage(systemName: "multiply.circle.fill"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        clear.setTitle("Clear", for: .normal)
        clear.tintColor = .black
        clear.setTitleColor(.black, for: .normal)
        clear.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        clear.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        clear.addTarget(self, action: #selector(rightBtnAction(_:)), for: .touchUpInside)
        let item = UIBarButtonItem(customView: clear)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
    }
    
    @objc func rightBtnAction(_ sender: UIButton) {
        txtDate.text = ""
        txtName.text = ""
        txtMessage.text = ""
    }
    
    func datePickerMethod() {
        let datePickerView: UIDatePicker        = UIDatePicker()
        
        if #available(iOS 13.4, *) {
            datePickerView.preferredDatePickerStyle = .wheels
        } else {
            
        }
        
        datePickerView.datePickerMode           = .time
        
        datePickerView.minimumDate              = Calendar.current.date(byAdding: .year, value: -10, to: Date())
        datePickerView.maximumDate              = Calendar.current.date(byAdding: .year, value: 10, to: Date())
        
        datePickerView.countDownDuration        = 10.0
        
        txtDate.inputView          = datePickerView
        datePickerView.addTarget(self, action: #selector(datePickerStayle(_:)), for: UIControl.Event.valueChanged)
        
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        txtDate.inputAccessoryView = toolBar
        
        let donebtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(createBarButtonDone))
        toolBar.setItems([donebtn], animated: true)
        
    }
    
    @objc func datePickerStayle(_ sender: UIDatePicker) {
        let dateFormate                         = DateFormatter()
        dateFormate.dateFormat                  = "HH:mm"
        txtDate.text               = dateFormate.string(from: sender.date)
    }
    
    @objc func createBarButtonDone(){
        self.view.endEditing(true)
    }
    
    @IBAction func btnSet(_ sender: Any) {
        if txtName.text!.isEmpty || txtDate.text!.isEmpty || txtMessage.text.isEmpty {
            alertVc(message: "Please enter a name or date or message in textfiled.")
        } else {
            
            if isBdReminder {
                bdID += 1
                UserDefaults.standard.set(bdID, forKey: "bdID")
                
                arrOfBdReminde.append(ReminderView(title: txtName.text!, message: txtMessage.text!, date: txtDate.text!))
                
                if let data = try? PropertyListEncoder().encode(arrOfBdReminde) {
                    UserDefaults.standard.set(data, forKey: "arrOfBdReminde")
                }
                
                scheduleNoti(txtName.text!, no: id, date: convertStringToDate(txtDate.text!)!)
                
                txtName.text = ""
                txtDate.text = ""
                txtMessage.text = ""
            } else {
                id += 1
                UserDefaults.standard.set(id, forKey: "id")
                
                arrOfReminde.append(ReminderView(title: txtName.text!, message: txtMessage.text!, date: txtDate.text!))
                
                if let data = try? PropertyListEncoder().encode(arrOfReminde) {
                    UserDefaults.standard.set(data, forKey: "arrOfReminde")
                }
                
                scheduleNoti(txtName.text!, no: id, date: convertStringToDate(txtDate.text!)!)
                
                txtName.text = ""
                txtDate.text = ""
                txtMessage.text = ""
            }
        }
    }
}
