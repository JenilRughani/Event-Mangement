//
//  SelectionViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit
import StoreKit

class CategoriesCell: UICollectionViewCell {
    @IBOutlet weak var viewBg: UIView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblName: UILabel!
}

class RecommCell: UICollectionViewCell {
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lbltitle: UILabel!
    @IBOutlet weak var viewbg: UIView!
}

class SelectionViewController: UIViewController {
    @IBOutlet weak var viewSearch: UIView!
    @IBOutlet weak var collectionCat: UICollectionView!
    @IBOutlet weak var collectionRecom: UICollectionView!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let data = UserDefaults.standard.data(forKey: "arrOfEvent") {
            arrOfEvent = try! PropertyListDecoder().decode([EventView].self, from: data)
            collectionRecom.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Selection"
        self.navigationItem.hidesBackButton = true
        
        viewsShadowApply(viewSearch)
        
        let tapGestgure = UITapGestureRecognizer(target: self, action: #selector(search))
        viewSearch.addGestureRecognizer(tapGestgure)
        viewSearch.isUserInteractionEnabled = true
        
        collectionCat.delegate = self
        collectionCat.dataSource = self
        collectionRecom.delegate = self
        collectionRecom.dataSource = self
    }
    
    @objc func search() {
        let search = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SearchWeatherViewController") as! SearchWeatherViewController
        self.navigationController?.pushViewController(search, animated: true)
    }
    
    @IBAction func btnCat(_ sender: Any) {
        let cat = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CatViewController") as! CatViewController
        self.navigationController?.pushViewController(cat, animated: true)
    }
    
    @IBAction func btnEvent(_ sender: Any) {
        let event = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DisplayEventViewController") as! DisplayEventViewController
        self.navigationController?.pushViewController(event, animated: true)
    }
}

//MARK: - CollectionView Delegate and DataSource Methods
extension SelectionViewController  : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch collectionView {
        case collectionCat :
            return arrOfCat.count
            
        case collectionRecom:
            return arrOfEvent.count
            
        default:
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        switch collectionView {
        case collectionCat :
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoriesCell", for: indexPath) as! CategoriesCell
            
            viewsShadowApply(cell.viewBg)
            cell.lblName.text = arrOfCat[indexPath.row].name
            cell.img.image = UIImage(named: arrOfCat[indexPath.row].img)
            
            return cell
            
        case collectionRecom:
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RecommCell", for: indexPath) as! RecommCell
            
            viewsShadowApply(cell.viewbg)
            cell.lbltitle.text = arrOfEvent[indexPath.row].title
            cell.img.image = generateQRCode(from: arrOfEvent[indexPath.row].message)
            
            return cell
            
        default:
            return UICollectionViewCell()
        }
    }
    
    func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)
        
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)
            
            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }
        return nil
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        switch collectionView {
        case collectionCat :
            return CGSize(width: (collectionView.bounds.width/4)-2, height: (collectionView.bounds.height/1)-2)
            
        case collectionRecom:
            return CGSize(width: (collectionView.bounds.width/1.1)-2, height: (collectionView.bounds.height/1)-2)
            
        default:
            return CGSize()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch collectionView {
        case collectionCat :
            
            switch indexPath.row {
            case 0:
                
                let event = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DisplayEventViewController") as! DisplayEventViewController
                self.navigationController?.pushViewController(event, animated: true)
                
            case 1:
                
                let task = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DisplayTaskViewController") as! DisplayTaskViewController
                self.navigationController?.pushViewController(task, animated: true)
                
            case 2:
                
                let reminder = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DisplayREminderViewController") as! DisplayREminderViewController
                self.navigationController?.pushViewController(reminder, animated: true)
                
            case 3:
                
                let cake = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DisplayREminderViewController") as! DisplayREminderViewController
                cake.isBDReminder = true
                self.navigationController?.pushViewController(cake, animated: true)
                
            case 4:
                
                let cal = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CalViewController") as! CalViewController
                self.navigationController?.pushViewController(cal, animated: true)
                
            case 5:
                
                let cal = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CalViewController") as! CalViewController
                cal.isAgeCal = true
                self.navigationController?.pushViewController(cal, animated: true)
                
            case 6:
                
                SKStoreReviewController.requestReview()
                
            case 7:
                
                let about = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AboutUsViewController") as! AboutUsViewController
                self.navigationController?.pushViewController(about, animated: true)
                
            default:
                break
            }
            
        case collectionRecom:
            
            eventactionSheet(title: "Action", message: nil, defaultTitle1: "Details", defaultTitle2: "Delete", destructiveTitle: "cancle") {
                let event = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
                event.strTitle = arrOfEvent[indexPath.row].title
                event.strPlace = arrOfEvent[indexPath.row].place
                event.strDate = arrOfEvent[indexPath.row].date
                event.strMessage = arrOfEvent[indexPath.row].message
                self.navigationController?.pushViewController(event, animated: true)
            } action2: {
                arrOfEvent.remove(at: indexPath.row)
                if let data = try? PropertyListEncoder().encode(arrOfEvent) {
                    UserDefaults.standard.set(data, forKey: "arrOfEvent")
                }
                self.collectionRecom.reloadData()
            }
            
        default:
            break
        }
    }
}
