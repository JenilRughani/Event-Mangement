//
//  AddEventViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

class AddEventViewController: UIViewController {
    @IBOutlet weak var txtTiele: UITextField!
    @IBOutlet weak var txtSubTitle: UITextField!
    @IBOutlet weak var txtPlace: UITextField!
    @IBOutlet weak var txtMessage: UITextView!
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var btnAdd: UIButton!
    
    var isUpdate: Bool = false
    var index: Int? = nil
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let data = UserDefaults.standard.data(forKey: "arrOfEvent") {
            arrOfEvent = try! PropertyListDecoder().decode([EventView].self, from: data)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = isUpdate ? "Update Event" : "Add Event"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        colorGradient()
        
        viewCornerBottom(view: viewMain)
        txtViewBorder(txt: txtMessage)
        
        if isUpdate {
            txtTiele.text = arrOfEvent[index!].title
            txtPlace.text = arrOfEvent[index!].place
            txtSubTitle.text = arrOfEvent[index!].subTitle
            txtMessage.text = arrOfEvent[index!].message
            btnAdd.setTitle("Update Event", for: .normal)
        } else {
            txtTiele.text = ""
            txtPlace.text = ""
            txtSubTitle.text = ""
            txtMessage.text = ""
            btnAdd.setTitle("Add Event", for: .normal)
        }
        
        let clear = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            clear.setImage(UIImage(systemName: "multiply.circle.fill"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        clear.setTitle("Clear", for: .normal)
        clear.tintColor = .black
        clear.setTitleColor(.black, for: .normal)
        clear.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        clear.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        clear.addTarget(self, action: #selector(rightBtnAction(_:)), for: .touchUpInside)
        let item = UIBarButtonItem(customView: clear)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
    }
    
    @objc func rightBtnAction(_ sender: UIButton) {
        txtTiele.text = ""
        txtPlace.text = ""
        txtSubTitle.text = ""
        txtMessage.text = ""
    }
    
    @IBAction func btnEvent(_ sender: Any) {
        if txtTiele.text!.isEmpty || txtPlace.text!.isEmpty || txtMessage.text!.isEmpty || txtSubTitle.text!.isEmpty {
            alertVc(message: "Please enter a name or date or message in textfiled.")
        } else {
            if isUpdate {
                arrOfEvent[index!].title = txtTiele.text!
                arrOfEvent[index!].subTitle = txtSubTitle.text!
                arrOfEvent[index!].place = txtPlace.text!
                arrOfEvent[index!].message = txtMessage.text!
                arrOfEvent[index!].date = getCurrntDate()
                arrOfEvent[index!].time = getCurrntTime()
            } else {
                arrOfEvent.append(EventView(title: txtTiele.text!, subTitle: txtSubTitle.text!, place: txtPlace.text!, message: txtMessage.text!, date: getCurrntDate(), time: getCurrntTime()))
            }
            
            if let data = try? PropertyListEncoder().encode(arrOfEvent) {
                UserDefaults.standard.set(data, forKey: "arrOfEvent")
            }
            
            txtTiele.text = ""
            txtPlace.text = ""
            txtSubTitle.text = ""
            txtMessage.text = ""
        }
    }
}
