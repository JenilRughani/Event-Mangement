//
//  SearchWeatherViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit
import MapKit
import CoreLocation

class SearchWeatherViewController: UIViewController {
    @IBOutlet weak var txtLat: UITextField!
    @IBOutlet weak var txtLon: UITextField!
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var btnSearch: UIButton!
    @IBOutlet weak var mpaView: MKMapView!
    @IBOutlet weak var lblLon: UILabel!
    @IBOutlet weak var lblLat: UILabel!
    
    var isArea: Bool = false
    let manager = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = isArea ? "Find Area" : "Search Weather"
        self.navigationItem.hidesBackButton = true
        
        btnSearch.setTitle(isArea ? "Find Area" : "Search Weather", for: .normal)
        
        if isArea {
            txtLon.isHidden = true
            lblLon.isHidden = true
            txtLat.placeholder = "name"
            lblLat.text = "Enter a name:"
        } else {
            txtLon.isHidden = false
            lblLon.isHidden = false
            txtLat.placeholder = "00.000"
            lblLat.text = "Enter a lat:"
        }
        
        leftNavVC()
        colorGradient()
        viewCornerBottom(view: viewMain)
        
        mpaView.isHidden = true
        mpaView.layer.cornerRadius = 10
        mpaView.layer.borderWidth = 3
        mpaView.layer.borderColor = UIColor(named: "orange")?.cgColor
        
        let clear = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            clear.setImage(UIImage(systemName: "multiply.circle.fill"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        clear.setTitle("Clear", for: .normal)
        clear.tintColor = .black
        clear.setTitleColor(.black, for: .normal)
        clear.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        clear.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        clear.addTarget(self, action: #selector(rightBtnAction(_:)), for: .touchUpInside)
        let item = UIBarButtonItem(customView: clear)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
    }
    
    @objc func rightBtnAction(_ sender: UIButton) {
        txtLat.text = ""
        txtLon.text = ""
        mpaView.isHidden = true
    }
    
    func getWeather(){
        
        let url: String = "https://api.api-ninjas.com/v1/weather?lat=\(txtLat.text!)&lon=\(txtLon.text!)"
        
        guard let url = URL(string: url) else {
            return debugPrint("URL Missing!!!")
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("9jJqjXodljsYkLtdFa5sZA==0XsW8wZVYEuv3wzy", forHTTPHeaderField: "X-Api-Key")
        
        createSpinnerView()
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard error == nil else
            {
                return debugPrint("Error:- \(String(describing: error?.localizedDescription))")
            }
            guard let res = response as? HTTPURLResponse else
            {
                return debugPrint("Error:- Response: \(String(describing: error?.localizedDescription))")
            }
            guard res.statusCode == 200 else
            {
                return debugPrint("Response Code:- \(res.statusCode)")
            }
            guard let jsonData = data else {
                return debugPrint("Error:- \(String(describing: error?.localizedDescription))")
            }
            
            let data = JSON(jsonData)
            
            DispatchQueue.main.async {
                self.removeSpinnerView()
                
                let weather = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DisplayWeatherViewController") as! DisplayWeatherViewController
                weather.data = data
                self.navigationController?.pushViewController(weather, animated: true)
            }
        }.resume()
    }
    
    func getArea(){
        
        let url: String = "https://api.api-ninjas.com/v1/city?name=\(txtLat.text!)"
        
        guard let url = URL(string: url) else {
            return debugPrint("URL Missing!!!")
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("9jJqjXodljsYkLtdFa5sZA==0XsW8wZVYEuv3wzy", forHTTPHeaderField: "X-Api-Key")
        
        createSpinnerView()
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            guard error == nil else
            {
                return debugPrint("Error:- \(String(describing: error?.localizedDescription))")
            }
            guard let res = response as? HTTPURLResponse else
            {
                return debugPrint("Error:- Response: \(String(describing: error?.localizedDescription))")
            }
            guard res.statusCode == 200 else
            {
                return debugPrint("Response Code:- \(res.statusCode)")
            }
            guard let jsonData = data else {
                return debugPrint("Error:- \(String(describing: error?.localizedDescription))")
            }
            
            let data = JSON(jsonData)
            
            DispatchQueue.main.async {
                self.removeSpinnerView()
                
                if data.arrayValue.isEmpty {
                    self.alertVc(message: "Data Not Found!")
                } else {
                    self.mpaView.isHidden = false
                    self.dicrectShareMap(lat: data.arrayValue[0].dictionaryValue["latitude"]?.doubleValue ?? 0.0, lon: data.arrayValue[0].dictionaryValue["longitude"]?.doubleValue ?? 0.0)
                }
            }
        }.resume()
    }
    
    private func dicrectShareMap(lat: Double, lon: Double) {
        let initialLocation = CLLocation(latitude: lat, longitude: lon)
        let regionRadius: CLLocationDistance = 1000
        let coordinateRegion = MKCoordinateRegion(center: initialLocation.coordinate,
                                                  latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
        mpaView.setRegion(coordinateRegion, animated: true)
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: lat, longitude: lon)
        mpaView.addAnnotation(annotation)
    }
    
    @IBAction func btnsearch(_ sender: Any) {
        if isArea {
            if txtLat.text!.isEmpty  {
                alertVc(message: "Please enter a city name in textfiled.")
            } else {
                getArea()
            }
        }
        else {
            if txtLat.text!.isEmpty || txtLon.text!.isEmpty {
                alertVc(message: "Please enter a lat or lon in textfiled.")
            } else {
                getWeather()
            }
        }
    }
}
