//
//  DisplayWeatherViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

class DisplayWeatherViewController: UIViewController {
    @IBOutlet weak var lblSpeed: UILabel!
    @IBOutlet weak var lblDegree: UILabel!
    @IBOutlet weak var lblTemp: UILabel!
    @IBOutlet weak var lblHundity: UILabel!
    @IBOutlet weak var lblCloud: UILabel!
    @IBOutlet weak var lblFeel: UILabel!
    @IBOutlet weak var lblsunrise: UILabel!
    @IBOutlet weak var lblSunset: UILabel!
    @IBOutlet weak var viewMain: UIView!
    
    var data: JSON? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Display Weather"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        colorGradient()
        viewCornerBottom(view: viewMain)
        
        lblFeel.text = String(data?.dictionaryValue["feels_like"]?.doubleValue ?? 0.0)
        lblTemp.text = String(data?.dictionaryValue["temp"]?.doubleValue ?? 0.0)
        lblCloud.text = String(data?.dictionaryValue["cloud_pct"]?.doubleValue ?? 0.0)
        lblSpeed.text = String(data?.dictionaryValue["wind_speed"]?.doubleValue ?? 0.0)
        lblDegree.text = String(data?.dictionaryValue["wind_degrees"]?.doubleValue ?? 0.0)
        lblHundity.text = String(data?.dictionaryValue["humidity"]?.doubleValue ?? 0.0)
        lblsunrise.text = convertInDateFomate(data?.dictionaryValue["sunrise"]?.doubleValue ?? 0.0)
        lblSunset.text = convertInDateFomate(data?.dictionaryValue["sunset"]?.doubleValue ?? 0.0)
    }
    
    private func convertInDateFomate(_ timeInter: TimeInterval) -> String {
        let date = Date(timeIntervalSince1970: timeInter)

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy hh:mm:ss a"
        let formattedDate = dateFormatter.string(from: date)
        return formattedDate
    }
    
    @IBAction func btnShare(_ sender: Any) {
        let textToShare = [String(data?.dictionaryValue["wind_speed"]?.doubleValue ?? 0.0)]
        let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
        activityViewController.excludedActivityTypes = [ UIActivity.ActivityType.airDrop, UIActivity.ActivityType.postToFacebook ]
        self.present(activityViewController, animated: true, completion: nil)
    }
}
