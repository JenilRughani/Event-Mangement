//
//  ViewController.swift
//  DateDotEventLensApp
//
//   
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var btnstart: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        img.layer.cornerRadius = 10
        btnstart.layer.cornerRadius = 10
    }
    
    @IBAction func btnStart(_ sender: Any) {
        let main = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "MainTabViewController") as! MainTabViewController
        self.navigationController?.pushViewController(main, animated: true)
    }
}
