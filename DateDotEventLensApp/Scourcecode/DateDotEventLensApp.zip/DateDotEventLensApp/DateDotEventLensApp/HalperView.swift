//
//  HalperView.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

//MARK: - UIViewController
extension UIViewController {
    
    //MARK: - colorGradient
    func colorGradient() {
        let gradient        = CAGradientLayer()
        gradient.type       = .axial
        gradient.frame      = view.bounds
        gradient.colors     = [UIColor.white.cgColor, UIColor.white.cgColor,UIColor(named: "black")!.cgColor,UIColor(named: "black")!.cgColor]
        gradient.locations  = [0,0.5, 0.75 ,1]
        view.layer.insertSublayer(gradient, at: 0)
    }
    
    //MARK: - createSpinnerView
    func createSpinnerView() {
        addChild(child)
        child.view.frame = view.frame
        view.addSubview(child.view)
        child.didMove(toParent: self)
    }
    
    //MARK: - removeSpinnerView
    func removeSpinnerView() {
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()
    }
    
    //MARK: - leftNavVC
    func leftNavVC() {
        let left = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            left.setImage(UIImage(systemName: "arrow.left"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        left.setTitle("Back", for: .normal)
        left.tintColor = .black
        left.setTitleColor(.black, for: .normal)
        left.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        left.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        left.addTarget(self, action: #selector(leftBtnAction(_:)), for: .touchUpInside)
        let item1 = UIBarButtonItem(customView: left)
        self.navigationItem.setLeftBarButtonItems([item1], animated: true)
    }
    
    @objc func leftBtnAction(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK: - alertVc
    func alertVc(title: String = "Alert", message: String) {
        let alert = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AlertViewController") as! AlertViewController
        alert.alertTiel = title
        alert.alertMessatge = message
        self.present(alert, animated: true)
    }
    
    //MARK: - ActionSheet Method
    func actionSheet(title: String?, message: String?,defaultTitle1: String?,defaultTitle2: String?, defaultTitle3: String?,defaultTitle4: String?, destructiveTitle: String?, action1: @escaping (()->()), action2: @escaping (()->()), action3: @escaping (()->()), action4: @escaping (()->())){
        let actionSheet = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        let cancleAs = UIAlertAction(title: destructiveTitle, style: .cancel)
        let firstButton = UIAlertAction(title: defaultTitle1, style: .default) { _ in
            action1()
        }
        let secoundButton = UIAlertAction(title: defaultTitle2, style: .default) { _ in
            action2()
        }
        
        let third = UIAlertAction(title: defaultTitle3, style: .default) { _ in
            action3()
        }
        let four = UIAlertAction(title: defaultTitle4, style: .default) { _ in
            action4()
        }
        actionSheet.addAction(firstButton)
        actionSheet.addAction(secoundButton)
        actionSheet.addAction(third)
        actionSheet.addAction(four)
        actionSheet.addAction(cancleAs)
        self.present(actionSheet, animated: true)
    }
    
    //MARK: - shadowApply
    func viewsShadowApply(_ view: UIView) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOpacity = 0.5
        view.layer.shadowOffset = .zero
        view.layer.shadowRadius = 5
        view.layer.cornerRadius = 10
    }
    
    //MARK: - viewCornerBottom
    func viewCornerBottom(view: UIView) {
       // view.roundCorners([.bottomLeft, .bottomRight], radius: 15)
        //viewsShadowApply(view)
    }
    
    //MARK: - txtViewBorder
    func txtViewBorder(txt: UITextView) {
        txt.layer.cornerRadius = 10
        txt.layer.borderWidth = 0.5
        txt.layer.borderColor = UIColor.darkGray.cgColor
    }
    
    //MARK: - scheduleNotification
    func scheduleNoti(_ title: String, no: Int, date: Date) {
        let content = UNMutableNotificationContent()
        content.title = title
        
        content.sound = UNNotificationSound.default
        
        let selectedTime = date
        
        let components = Calendar.current.dateComponents([.hour, .minute], from: selectedTime)
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: true)
        
        let request = UNNotificationRequest(identifier: "app.\(no)", content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Error scheduling notification: \(error.localizedDescription)")
            } else {
                print("Notification scheduled successfully")
            }
        }
    }

    //MARK: - convertStringToDate
    func convertStringToDate(_ dateString: String) -> Date? {
        let dateFormatter = DateFormatter()

        dateFormatter.dateFormat = "HH:mm"

        let dateString = dateString

        if let date = dateFormatter.date(from: dateString) {
            return date
        } else {
            print("Could not convert string to date")
            return nil
        }
    }
    
    //MARK: - getCurrntTime
    func getCurrntTime() -> String {
        return Date().timeLocalizedDescription
    }
    
    //MARK: - getCurrntDate
    func getCurrntDate() -> String {
        return Date().dateLocalizedDescription
    }
    
    //MARK: - viewCapsulte
    func viewCapsulte(_ view: UIView) {
        view.layer.cornerRadius = view.bounds.height / 2
    }
    
    //MARK: - eventactionSheet
    func eventactionSheet(title: String?, message: String?,defaultTitle1: String?,defaultTitle2: String?, destructiveTitle: String?, action1: @escaping (()->()), action2: @escaping (()->())){
        let actionSheet = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        let cancleAs = UIAlertAction(title: destructiveTitle, style: .cancel)
        let firstButton = UIAlertAction(title: defaultTitle1, style: .default) { _ in
            action1()
        }
        let secoundButton = UIAlertAction(title: defaultTitle2, style: .destructive) { _ in
            action2()
        }
        actionSheet.addAction(firstButton)
        actionSheet.addAction(secoundButton)
        actionSheet.addAction(cancleAs)
        self.present(actionSheet, animated: true)
    }
}

//MARK: - TimeZone
extension TimeZone {
    static let gmt = TimeZone(secondsFromGMT: 0)!
}

//MARK: - Locale
extension Locale {
    static let ptBR = Locale(identifier: "pt_BR")
}

//MARK: - Formatter
extension Formatter {
    static let date = DateFormatter()
}

//MARK: - Date
extension Date {
    
    func timeLocalizedDescriptions(in timeZone: TimeZone = .current,
                               locale: Locale = .current,
                               using calendar: Calendar = .current) -> String {
        Formatter.date.calendar = calendar
        Formatter.date.locale = locale
        Formatter.date.timeZone = timeZone
        Formatter.date.dateFormat = "hh:mm a"
        return Formatter.date.string(from: self)
    }
    
    func dateLocalizedDescriptions(in timeZone: TimeZone = .current,
                               locale: Locale = .current,
                               using calendar: Calendar = .current) -> String {
        Formatter.date.calendar = calendar
        Formatter.date.locale = locale
        Formatter.date.timeZone = timeZone
        Formatter.date.dateFormat = "dd/MM/yyyy"
        return Formatter.date.string(from: self)
    }
    
    var timeLocalizedDescription: String { timeLocalizedDescriptions() }
    var dateLocalizedDescription: String { dateLocalizedDescriptions() }
}

//MARK: - UIView
extension UIView {
    func roundCorners(_ corners: UIRectCorner, radius: Double) {
        let maskPath = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let shape = CAShapeLayer()
        shape.path = maskPath.cgPath
        layer.mask = shape
    }
}

//MARK: - UITableView
extension UITableView {
    
    func setEmptyDataImage() {
        backgroundView = nil
        
        let containerView = UIView(frame: bounds)
        
        let imageView = UIImageView(image: UIImage(named: "empty"))
        imageView.frame = CGRect(x: (bounds.width - 150) / 2, y: (bounds.height - 150) / 2 - 20, width: 150, height: 150)
        imageView.contentMode = .scaleAspectFit
        
        let label = UILabel()
        label.text = "Empty Data"
        label.textColor = .gray
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 18)
        
        label.frame = CGRect(x: 0, y: imageView.frame.maxY + 10, width: bounds.width, height: 20)
        
        containerView.addSubview(imageView)
        containerView.addSubview(label)
        
        backgroundView = containerView
    }
    
    func restoreEmptyDataImage() {
        backgroundView = nil
    }
}

//MARK: - UICollectionView
extension UICollectionView {
    
    func setEmptyDataImage() {
        backgroundView = nil
        
        let containerView = UIView(frame: bounds)
        
        let imageView = UIImageView(image: UIImage(named: "empty"))
        imageView.frame = CGRect(x: (bounds.width - 150) / 2, y: (bounds.height - 150) / 2 - 20, width: 150, height: 150)
        imageView.contentMode = .scaleAspectFit
        
        let label = UILabel()
        label.text = "Empty Data"
        label.textColor = .gray
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 18)
        
        label.frame = CGRect(x: 0, y: imageView.frame.maxY + 10, width: bounds.width, height: 20)
        
        containerView.addSubview(imageView)
        containerView.addSubview(label)
        
        backgroundView = containerView
    }
    
    func restoreEmptyDataImage() {
        backgroundView = nil
    }
}

let child = SpinnerViewController()

//MARK: - SpinnerViewController
class SpinnerViewController: UIViewController {
    var spinner = UIActivityIndicatorView(style: .whiteLarge)
    
    override func loadView() {
        view = UIView()
        view.backgroundColor = UIColor(white: 0, alpha: 0.7)
        
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.startAnimating()
        spinner.color = UIColor.white
        view.addSubview(spinner)
        
        spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        spinner.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
    }
}

