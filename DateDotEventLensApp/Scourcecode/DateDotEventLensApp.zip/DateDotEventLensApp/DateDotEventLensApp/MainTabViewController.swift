//
//  MainTabViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

class MainTabViewController: UIViewController, BackOpenVc {
    @IBOutlet weak var viewBg: UIView!
    @IBOutlet weak var viewHome: UIView!
    @IBOutlet weak var viewStar: UIView!
    @IBOutlet weak var viewCalender: UIView!
    @IBOutlet weak var btnHome: UIButton!
    @IBOutlet weak var btnStart: UIButton!
    @IBOutlet weak var btnCalender: UIButton!
    
    var pageController = UIPageViewController()
    var index: Int = 0
    var indexPage: Int = 0
    var pageViewConreollerCount: Int = 0
    
    var arrOfVC: [UIViewController] = [
        UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SelectionViewController"),
        UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "StarSelectionViewController"), 
        UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "LocationViewController"),
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Home"
        self.navigationItem.hidesBackButton = true
        
        pageVC()
        selectionTab()
        colorGradient()
        
        viewCapsulte(viewHome)
        viewCapsulte(viewStar)
        viewCapsulte(viewCalender)
        
        let pop = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            pop.setImage(UIImage(systemName: "gear"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        pop.setTitle("Other", for: .normal)
        pop.tintColor = .black
        pop.setTitleColor(.black, for: .normal)
        pop.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        pop.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        pop.addTarget(self, action: #selector(rightBtnAction(_:)), for: .touchUpInside)
        let item = UIBarButtonItem(customView: pop)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
        
        btnHome.tintColor = UIColor.white
        btnStart.tintColor = UIColor.white
        btnCalender.tintColor = UIColor.white
    }
    
    @objc func rightBtnAction(_ sender: UIButton) {
        let pop = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CustomPopViewController") as! CustomPopViewController
        pop.delegate = self
        self.present(pop, animated: true)
    }
    
    func openVc(state: OpenState) {
        switch state {
        case .Translate:
            let transl = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TranslateViewController") as! TranslateViewController
            self.navigationController?.pushViewController(transl, animated: true)
        case .QR:
            let qr = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SearchTaskViewController") as! SearchTaskViewController
            qr.isQrScreen = true
            self.navigationController?.pushViewController(qr, animated: true)
        case .Converter:
            let converter = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CalViewController") as! CalViewController
            converter.isconverter = true
            self.navigationController?.pushViewController(converter, animated: true)
        case .Area:
            let search = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SearchWeatherViewController") as! SearchWeatherViewController
            search.isArea = true
            self.navigationController?.pushViewController(search, animated: true)
        }
    }
    
    func selectionTab() {
        switch indexPage {
        case 0:
            title = "Home"
            viewHome.backgroundColor = UIColor(named: "orange")
            viewStar.backgroundColor = .clear
            viewCalender.backgroundColor = .clear
            
        case 1:
            title = "Star Data"
            viewHome.backgroundColor = UIColor.clear
            viewStar.backgroundColor = UIColor(named: "orange")
            viewCalender.backgroundColor = .clear
            
        case 2:
            title = "Location"
            viewHome.backgroundColor = UIColor.clear
            viewStar.backgroundColor = .clear
            viewCalender.backgroundColor = UIColor(named: "orange")
     
        default:
            break
        }
    }
    
    func pageVC() {
        pageController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        pageController.view.backgroundColor = .clear
        pageController.view.frame = viewBg.bounds
        viewBg.addSubview(pageController.view)
        addChild(pageController)
        pageController.didMove(toParent: self)
//        pageController.delegate = self
//        pageController.dataSource = self
        pageController.setViewControllers([arrOfVC[0]], direction: .forward, animated: false, completion: nil)
        selectionTab()
    }
    
    func shadowView(_ view: UIView) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = CGSize(width: 3, height: 5)
        view.layer.shadowRadius = 6
        view.layer.shadowOpacity = 0.5
        view.layer.cornerRadius = 10
    }
    
    func removeShadowView(_ view: UIView) {
        view.layer.shadowColor = UIColor.clear.cgColor
        view.layer.shadowOffset = CGSize(width: 0, height: 0)
        view.layer.shadowRadius = 0
        view.layer.shadowOpacity = 0
        view.layer.cornerRadius = 0
    }
    
    @IBAction func btnHome(_ sender: Any) {
        title = "Home"
        index = 0
        indexPage = index
        selectionTab()
        pageController.setViewControllers([arrOfVC[index]], direction: pageViewConreollerCount <= indexPage ? .forward : .reverse, animated: true, completion: nil)
        pageViewConreollerCount = index
    }
    
    @IBAction func btnStar(_ sender: Any) {
        title = "Star"
        index = 1
        indexPage = index
        selectionTab()
        pageController.setViewControllers([arrOfVC[index]], direction: pageViewConreollerCount <= indexPage ? .forward : .reverse, animated: true, completion: nil)
        pageViewConreollerCount = index
    }
    
    @IBAction func btnCal(_ sender: Any) {
        title = "Calender"
        index = 2
        indexPage = index
        selectionTab()
        pageController.setViewControllers([arrOfVC[index]], direction: pageViewConreollerCount <= indexPage ? .forward : .reverse, animated: true, completion: nil)
        pageViewConreollerCount = index
    }
}

//extension MainTabViewController: UIPageViewControllerDelegate, UIPageViewControllerDataSource {
//    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
//        
//        guard let page = arrOfVC.firstIndex(of: viewController), 0 < page else {
//            return nil
//        }
//       
//        let before = page - 1
//        return arrOfVC[before]
//    }
//    
//    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
//        guard let page = arrOfVC.firstIndex(of: viewController), (arrOfVC.count-1) > page else {
//            return nil
//        }
//       
//        let after = page + 1
//        return arrOfVC[after]
//    }
//    
//    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
//        selectionTab()
//    }
//}
