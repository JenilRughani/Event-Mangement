//
//  StarEventsViewController.swift
//  DateDotEventLensApp
//
//   
//

import UIKit

class StarEventCell: UITableViewCell {
    @IBOutlet weak var viewbg: UIView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblMessage: UILabel!
    
}

class StarEventsViewController: UIViewController {
    @IBOutlet weak var tabelView: UITableView!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let data = UserDefaults.standard.data(forKey: "arrOfStarEvent") {
            arrOfStarEvent = try! PropertyListDecoder().decode([EventView].self, from: data)
            tabelView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
     
        tabelView.delegate = self
        tabelView.dataSource = self
    }
    
    func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)
        
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            let transform = CGAffineTransform(scaleX: 3, y: 3)
            
            if let output = filter.outputImage?.transformed(by: transform) {
                return UIImage(ciImage: output)
            }
        }
        return nil
    }
}

extension StarEventsViewController : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        arrOfStarEvent.isEmpty ? tableView.setEmptyDataImage() : tableView.restoreEmptyDataImage()
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrOfStarEvent.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StarEventCell", for: indexPath) as! StarEventCell
        
        viewsShadowApply(cell.viewbg)
        cell.lblTitle.text = arrOfStarEvent[indexPath.row].title
        cell.lblMessage.text = arrOfStarEvent[indexPath.row].message
        cell.img.image = generateQRCode(from: arrOfStarEvent[indexPath.row].message)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let details = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
        details.strPlace = arrOfStarEvent[indexPath.row].place
        details.strDate =  arrOfStarEvent[indexPath.row].date
        details.strTitle = arrOfStarEvent[indexPath.row].title
        details.strMessage = arrOfStarEvent[indexPath.row].message
        self.navigationController?.pushViewController(details, animated: true)
    }
}

