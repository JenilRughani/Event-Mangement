//
//  DisplayTaskViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

struct TaskView: Codable {
    var title: String
    var message: String
    var place: String
    var state: String
    var currentDate: String
    var currentTime: String
}

var arrOfTask: [TaskView] = []

class TaskViewCell: UITableViewCell {
    @IBOutlet weak var viewbg: UIView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblMEssage: UILabel!
    @IBOutlet weak var btnView: UIButton!
    @IBOutlet weak var btnstar: UIButton!
    @IBOutlet weak var btnState: UIButton!
    
    var action: (()->()) = {}
    var actionStar: (()->()) = {}
    
    @IBAction func btnAction(_ sender: UIButton) {
        action()
    }
    
    @IBAction func btnstar(_ sender: Any) {
        actionStar()
    }
}

class DisplayTaskViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let data = UserDefaults.standard.data(forKey: "arrOfTask") {
            arrOfTask = try! PropertyListDecoder().decode([TaskView].self, from: data)
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Tasks"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        
        let add = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            add.setImage(UIImage(systemName: "plus"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        add.setTitle("Task", for: .normal)
        add.tintColor = .black
        add.setTitleColor(.black, for: .normal)
        add.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        add.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        add.addTarget(self, action: #selector(rightBtnAction(_:)), for: .touchUpInside)
        let item = UIBarButtonItem(customView: add)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
        
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    @objc func rightBtnAction(_ sender: UIButton) {
        let add = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SearchTaskViewController") as! SearchTaskViewController
        self.navigationController?.pushViewController(add, animated: true)
    }
    
    func generateQRCode(from string: String) -> UIImage? {
        let data = string.data(using: String.Encoding.ascii)
        
        if let filter = CIFilter(name: "CIQRCodeGenerator") {
            filter.setValue(data, forKey: "inputMessage")
            filter.setValue("Q", forKey: "inputCorrectionLevel")
            
            guard let qrCodeImage = filter.outputImage else { return nil }
            
            let scaledQRCode = qrCodeImage.transformed(by: CGAffineTransform(scaleX: 10, y: 10))
            
            return UIImage(ciImage: scaledQRCode)
        }
        
        return nil
    }

}

extension DisplayTaskViewController : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        arrOfTask.isEmpty ? tableView.setEmptyDataImage() : tableView.restoreEmptyDataImage()
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrOfTask.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskViewCell", for: indexPath) as! TaskViewCell
        
        viewsShadowApply(cell.viewbg)
        cell.btnView.layer.cornerRadius = 10
        cell.btnState.layer.cornerRadius = 10
        cell.lblTitle.text = arrOfTask[indexPath.row].title
        cell.lblMEssage.text = arrOfTask[indexPath.row].message
        cell.img.image = generateQRCode(from: arrOfTask[indexPath.row].message)
        cell.btnState.setTitle(arrOfTask[indexPath.row].state, for: .normal)
        
        if arrOfTask[indexPath.row].state == "Argent" {
            cell.btnState.backgroundColor = UIColor(named: "yellow")
        } else {
            cell.btnState.backgroundColor = UIColor(named: "green")
            
        }
        
        cell.action = {
            let details = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
            details.strTitle = arrOfTask[indexPath.row].title
            details.strPlace = arrOfTask[indexPath.row].place
            details.strDate = arrOfTask[indexPath.row].currentDate
            details.strMessage = arrOfTask[indexPath.row].message
            self.navigationController?.pushViewController(details, animated: true)
        }
        
        cell.actionStar = {
            arrOfStarTask.append(arrOfTask[indexPath.row])
            
            if let data = try? PropertyListEncoder().encode(arrOfStarTask) {
                UserDefaults.standard.set(data, forKey: "arrOfStarTask")
            }
            
            if #available(iOS 13.0, *) {
                cell.btnstar.setImage(UIImage(systemName: "star.fill"), for: .normal)
                cell.btnstar.tintColor = UIColor.systemYellow
            } else {
                // Fallback on earlier versions
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) {
                arrOfTask.remove(at: indexPath.row)
                
                if let data = try? PropertyListEncoder().encode(arrOfTask) {
                    UserDefaults.standard.set(data, forKey: "arrOfTask")
                }
                
                self.tableView.reloadData()
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let task = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SearchTaskViewController") as! SearchTaskViewController
        task.isUpdate = true
        task.index = indexPath.row
        self.navigationController?.pushViewController(task, animated: true)
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        tableView.beginUpdates()
        arrOfTask.remove(at: indexPath.row)
        tableView.deleteRows(at: [indexPath], with: .fade)
        
        if let data = try? PropertyListEncoder().encode(arrOfTask) {
            UserDefaults.standard.set(data, forKey: "arrOfTask")
        }
        
        tableView.endUpdates()
    }
}
