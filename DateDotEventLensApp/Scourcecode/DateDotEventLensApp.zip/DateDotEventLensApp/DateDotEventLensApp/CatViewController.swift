//
//  CatViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit
import StoreKit

struct Categories: Codable {
    var img: String
    var name: String
}

var arrOfCat: [Categories] = [
    Categories(img: "calendar-check", name: "Event"),
    Categories(img: "checklist", name: "Task"),
    Categories(img: "reminder", name: "Reminder"),
    Categories(img: "birthday-cake", name: "Cake"),
    Categories(img: "calculator", name: "Cal"),
    Categories(img: "age-group", name: "Age Cal"),
    Categories(img: "star", name: "Rate Us"),
    Categories(img: "information", name: "About Us"),
]

class CatCell: UICollectionViewCell {
    @IBOutlet weak var viewbg: UIView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    
}

class CatViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Category"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        
        collectionView.delegate = self
        collectionView.dataSource = self
    }
}

//MARK: - CollectionView Delegate and DataSource Methods
extension CatViewController  : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrOfCat.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CatCell", for: indexPath) as! CatCell
        
        viewsShadowApply(cell.viewbg)
        cell.lblName.text = arrOfCat[indexPath.row].name
        cell.img.image = UIImage(named: arrOfCat[indexPath.row].img)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (collectionView.bounds.width/2)-2, height: (collectionView.bounds.height/2.75)-2)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            
            let event = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DisplayEventViewController") as! DisplayEventViewController
            self.navigationController?.pushViewController(event, animated: true)
            
        case 1:
            
            let task = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DisplayTaskViewController") as! DisplayTaskViewController
            self.navigationController?.pushViewController(task, animated: true)
            
        case 2:
            
            let reminder = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DisplayREminderViewController") as! DisplayREminderViewController
            self.navigationController?.pushViewController(reminder, animated: true)
            
        case 3:
            
            let cake = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DisplayREminderViewController") as! DisplayREminderViewController
            cake.isBDReminder = true
            self.navigationController?.pushViewController(cake, animated: true)
            
        case 4:
            
            let cal = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CalViewController") as! CalViewController
            self.navigationController?.pushViewController(cal, animated: true)
            
        case 5:
            
            let cal = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CalViewController") as! CalViewController
            cal.isAgeCal = true
            self.navigationController?.pushViewController(cal, animated: true)
            
        case 6:
            
            SKStoreReviewController.requestReview()
            
        case 7:
            
            let about = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AboutUsViewController") as! AboutUsViewController
            self.navigationController?.pushViewController(about, animated: true)
            
        default:
            break
        }
    }
}
