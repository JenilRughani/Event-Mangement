//
//  TranslateViewController.swift
//  DateDotEventLensApp
//
//   
//

import UIKit

class TranslateViewController: UIViewController {
    @IBOutlet weak var lblAns: UILabel!
    @IBOutlet weak var viewBg: UIView!
    @IBOutlet weak var txtView: UITextView!
    @IBOutlet weak var viewMain: UIView!
    
    var source: String = "en"
    var target: String = "ar"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Translate"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        colorGradient()
        viewCornerBottom(view: viewMain)
        txtViewBorder(txt: txtView)
        viewsShadowApply(viewBg)
        
        self.viewBg.isHidden = true
        
        let clear = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            clear.setImage(UIImage(systemName: "multiply.circle.fill"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        clear.setTitle("Clear", for: .normal)
        clear.tintColor = .black
        clear.setTitleColor(.black, for: .normal)
        clear.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        clear.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        clear.addTarget(self, action: #selector(rightBtnAction(_:)), for: .touchUpInside)
        let item = UIBarButtonItem(customView: clear)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
    }
    
    @objc func rightBtnAction(_ sender: UIButton) {
        txtView.text = ""
        self.viewBg.isHidden = true
    }
    
    func getTrans() {
        guard let url = URL(string: "https://Translate.proxy-production.allthingsdev.co/translate?translated_from=eng&translated_to=hin") else {
            debugPrint("Error: Invalid URL")
            return
        }
        
        var request = URLRequest(url: url, timeoutInterval: Double.infinity)
        request.addValue("jX-T0B-CuT8udCkzyuwBOwrV2vmio-WYd2ljc74oOgwursPrQP", forHTTPHeaderField: "x-apihub-key")
        request.addValue("Translate.allthingsdev.co", forHTTPHeaderField: "x-apihub-host")
        request.addValue("3f4ee5f4-f67c-4c5a-9375-635d8b514026", forHTTPHeaderField: "x-apihub-endpoint")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        
        // Prepare JSON request body
        let inputText = txtView.text ?? ""
        let parameters: [String: Any] = ["input": inputText]
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted)
            request.httpBody = jsonData
        } catch {
            debugPrint("Error: Unable to serialize JSON - \(error.localizedDescription)")
            return
        }
        
        // Show spinner
        createSpinnerView()
        
        // Perform the network request
        URLSession.shared.dataTask(with: request) { data, response, error in
            // Error handling
            if let error = error {
                DispatchQueue.main.async {
                    self.removeSpinnerView()
                    self.alertVc(message: "Error: \(error.localizedDescription)")
                }
                return debugPrint("Error: \(error.localizedDescription)")
            }
            
            // Check if the response is valid
            guard let httpResponse = response as? HTTPURLResponse else {
                DispatchQueue.main.async {
                    self.removeSpinnerView()
                    self.alertVc(message: "Error: Invalid response")
                }
                return debugPrint("Error: Invalid response")
            }
            
            // Check for status code 200
            guard httpResponse.statusCode == 200 else {
                DispatchQueue.main.async {
                    self.removeSpinnerView()
                    self.alertVc(message: "Something went wrong! Response code: \(httpResponse.statusCode)")
                }
                return debugPrint("Error: Response code \(httpResponse.statusCode)")
            }
            
            // Ensure there is data in the response
            guard let jsonData = data else {
                DispatchQueue.main.async {
                    self.removeSpinnerView()
                    self.alertVc(message: "Error: No data received")
                }
                return debugPrint("Error: No data received")
            }
            
            do {
                let json = try JSON(data: jsonData)
                let translations = json["translation"].arrayValue.map { $0.stringValue }
                
                DispatchQueue.main.async {
                    self.removeSpinnerView()
                    self.viewBg.isHidden = false
                    self.lblAns.text = translations.joined(separator: ", ")
                }
            } catch {
                DispatchQueue.main.async {
                    self.removeSpinnerView()
                    self.alertVc(message: "Error parsing response")
                }
                return debugPrint("Error parsing response: \(error.localizedDescription)")
            }
            
        }.resume()
    }


    
    @IBAction func btnTranslate(_ sender: Any) {
        if txtView.text.isEmpty {
            alertVc(message: "Plese enter a text in textfiled.")
        } else {
            getTrans()
        }
    }
}
