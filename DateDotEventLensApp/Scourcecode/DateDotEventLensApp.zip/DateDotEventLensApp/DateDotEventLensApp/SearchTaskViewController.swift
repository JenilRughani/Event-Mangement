//
//  SearchTaskViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

class SearchTaskViewController: UIViewController {
    @IBOutlet weak var txttile: UITextField!
    @IBOutlet weak var txtSate: UITextField!
    @IBOutlet weak var txtPlace: UITextField!
    @IBOutlet weak var txtMessagte: UITextView!
    @IBOutlet weak var viewMain: UIView!
    @IBOutlet weak var btnTask: UIButton!
    @IBOutlet weak var lblState: UILabel!
    
    var picker = UIPickerView()
    var arrOfState: [String] = ["Argent", "Normal"]
    var isUpdate: Bool = false
    var index: Int? = nil
    var isQrScreen: Bool = false
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let data = UserDefaults.standard.data(forKey: "arrOfTask") {
            arrOfTask = try! PropertyListDecoder().decode([TaskView].self, from: data)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = isQrScreen ? "QR Code" : isUpdate  ? "Update Task" : "Add Task"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        colorGradient()
        viewCornerBottom(view: viewMain)
        txtViewBorder(txt: txtMessagte)
        
        if isQrScreen {
            txttile.text = ""
            txtPlace.text = ""
            txtMessagte.text = ""
            txtSate.text = ""
            lblState.text = "Enter a Date:"
            txtSate.placeholder = "dd/MM/yyyy"
            datePickerMethod()
            btnTask.setTitle("QR Code", for: .normal)
        } else {
            lblState.text = "Select a State:"
            txtSate.placeholder = "select"
            
            picker.delegate = self
            picker.dataSource = self
            txtSate.inputView = picker
            
            if isUpdate {
                txttile.text = arrOfTask[index!].title
                txtPlace.text = arrOfTask[index!].place
                txtMessagte.text = arrOfTask[index!].message
                txtSate.text = arrOfTask[index!].state
                btnTask.setTitle("Update Task", for: .normal)
            } else {
                txttile.text = ""
                txtPlace.text = ""
                txtMessagte.text = ""
                txtSate.text = ""
                btnTask.setTitle("Add Task", for: .normal)
            }
        }
        
        let clear = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            clear.setImage(UIImage(systemName: "multiply.circle.fill"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        clear.setTitle("Clear", for: .normal)
        clear.tintColor = .black
        clear.setTitleColor(.black, for: .normal)
        clear.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        clear.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        clear.addTarget(self, action: #selector(rightBtnAction(_:)), for: .touchUpInside)
        let item = UIBarButtonItem(customView: clear)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
    }
    
    @objc func rightBtnAction(_ sender: UIButton) {
        txttile.text = ""
        txtSate.text = ""
        txtPlace.text = ""
        txtMessagte.text = ""
    }
    
    func datePickerMethod() {
        
        let datePickerView: UIDatePicker        = UIDatePicker()
        
        //NOTE: - Show The Differnts Patten in keyboread
        if #available(iOS 14.0, *) {
            datePickerView.preferredDatePickerStyle = .wheels
        } else {
            // Fallback on earlier versions
        }
        
        //NOTE: - select the Time, Date , DateAndTime, etc...
        datePickerView.datePickerMode           = .date
        
        //NOTE: - Set The Minimum And Maximum Value...
        datePickerView.minimumDate              = Calendar.current.date(byAdding: .year, value: -10, to: Date())
        datePickerView.maximumDate              = Calendar.current.date(byAdding: .year, value: 10, to: Date())
        
        //NOTE: - Duration Between 10-10 Minites!! [ i.e. 10,20,30 minites ]
        //datePickerView.minuteInterval           = 10
        
        datePickerView.countDownDuration        = 10.0
        
        txtSate.inputView          = datePickerView
        datePickerView.addTarget(self, action: #selector(datePickerStayle(_:)), for: UIControl.Event.valueChanged)
        
        
        //NOTE: - Create the New bar Button in KeyBoeard -> "Done"
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        txtSate.inputAccessoryView = toolBar
        
        let donebtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(createBarButtonDone))
        toolBar.setItems([donebtn], animated: true)
        
    }
    @objc func datePickerStayle(_ sender: UIDatePicker) {
        let dateFormate                         = DateFormatter()
        //dateFormate.dateStyle                   = .medium
        //dateFormate.timeStyle                   = .medium
        
        //NOTE: - TimeZone:- Deside the Current Time in Countery....
        dateFormate.dateFormat                  = "dd/MM/yyyy"
        txtSate.text               = dateFormate.string(from: sender.date)
    }
    
    @objc func createBarButtonDone(){
        self.view.endEditing(true)
    }
    
    @IBAction func btnTask(_ sender: Any) {
        if txttile.text!.isEmpty || txtSate.text!.isEmpty || txtPlace.text!.isEmpty || txtMessagte.text.isEmpty {
            alertVc(message: "Please enter a name or date or message in textfiled.")
        } else {
            if isQrScreen {
                
                let details = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailsViewController") as! DetailsViewController
                details.strDate = txtSate.text!
                details.strPlace = txtPlace.text!
                details.strTitle = txttile.text!
                details.strMessage = txtMessagte.text!
                self.navigationController?.pushViewController(details, animated: true)
                
            } else {
                if isUpdate {
                    arrOfTask[index!].title = txttile.text!
                    arrOfTask[index!].message = txtMessagte.text!
                    arrOfTask[index!].place = txtPlace.text!
                    arrOfTask[index!].state = txtSate.text!
                    arrOfTask[index!].currentDate = getCurrntDate()
                    arrOfTask[index!].currentTime = getCurrntTime()
                } else {
                    arrOfTask.append(TaskView(title: txttile.text!, message: txtMessagte.text!, place: txtPlace.text!, state: txtSate.text!, currentDate: getCurrntDate(), currentTime: getCurrntTime()))
                }
                
                if let data = try? PropertyListEncoder().encode(arrOfTask) {
                    UserDefaults.standard.set(data, forKey: "arrOfTask")
                }
                
                txttile.text = ""
                txtSate.text = ""
                txtPlace.text = ""
                txtMessagte.text = ""
            }
        }
    }
}

//MARK: - UIPickerView Delegate methods
extension SearchTaskViewController: UIPickerViewDelegate, UIPickerViewDataSource {
    //Display the PickerView
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    //Display the Picker Components
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrOfState.count
    }
    
    //Display the Rows
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrOfState[row]
    }
    
    //print the Selected Rows in textfileds.
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        txtSate.text = arrOfState[row]
    }
}
