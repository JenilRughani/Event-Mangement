//
//  AboutUsViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

class AboutUsViewController: UIViewController {
    @IBOutlet weak var lblAbout: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "About Us"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        colorGradient()
        
        lblAbout.text = """
The DateDotEventLensApp is a versatile iOS application designed to provide users with a comprehensive set of functionalities. Here's a detailed breakdown of its features:

    1. Event Management: Users can effortlessly create, store, and manage their events. Each event can be customized by adding a title, subtitle, location, and message. Users can update or delete events as needed, offering a streamlined approach to organizing personal or professional plans.

    2. Task Management: The app allows users to add tasks with essential details such as a title, urgency state (Normal or Urgent), location, and message. Similar to events, tasks can also be managed, updated, or deleted easily, making task tracking efficient and customizable.

    3. Star Feature: This unique functionality lets users highlight important events or tasks by moving them into a dedicated "Star Area." It helps users prioritize specific items, ensuring that important events or tasks are easily accessible.

    4. Custom Reminders: Users can create personalized reminders, ensuring that they never miss important deadlines, meetings, or any other events that require timely alerts.

    5. Cake Reminder: A specialized birthday reminder feature, where users can input names, dates, and messages for upcoming birthdays. The app sends notifications on the specified date to help users remember to celebrate their loved ones.

    6. Calculator: The app includes a built-in calculator capable of performing basic arithmetic operations like addition, multiplication, subtraction, and division, catering to quick calculations.

    7. Age Calculator: Users can input two birthdates and calculate the difference between two individuals in years, months, and days. This feature is particularly useful for comparing ages in various contexts.

    8. Weather Information: By entering latitude and longitude, users can retrieve detailed weather information, including wind speed and direction, temperature, humidity, cloud coverage, "feels like" temperature, as well as sunrise and sunset times.

    9. Location Display: The app displays the user's current location, which can be shared with others. It’s helpful for personal use or sharing your whereabouts with friends and family.

    10. Translation: The app provides a translation feature where users can input an English sentence and receive its Hindi translation, assisting with language barriers or learning.

    11. QR Code Generator: Users can generate custom QR codes by entering details like title, date, place, and description, making it a handy tool for sharing information quickly through scannable codes.

    12. Basic Converter: This feature allows users to select a unit converter, input a value, and get the converted measurement. It's particularly useful for converting between different units like length, weight, and temperature.

    13. Area Finder: By entering a city name, users can retrieve a custom map view, enabling them to explore locations and visualize geographical areas of interest.

Each of these functionalities works together to make DateDotEventLensApp a highly useful and feature-rich tool for managing daily activities, personal information, and utility-based needs.So Download the DateDotEventLensApp And Use Today!
"""
    }
    
    @IBAction func btnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}
