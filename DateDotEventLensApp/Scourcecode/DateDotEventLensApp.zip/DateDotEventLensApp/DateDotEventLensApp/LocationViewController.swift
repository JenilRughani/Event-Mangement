//
//  LocationViewController.swift
//  DateDotEventLensApp
//
//   
//

import UIKit
import MapKit
import CoreLocation

class LocationViewController: UIViewController {
    @IBOutlet weak var mpaview: MKMapView!
    
    let manager = CLLocationManager()
    var logitutde: String = ""
    var latitude: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Location"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        colorGradient()
        
        let refresh = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            refresh.setImage(UIImage(systemName: "arrow.counterclockwise"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        refresh.setTitle("Refresh", for: .normal)
        refresh.tintColor = .black
        refresh.setTitleColor(.black, for: .normal)
        refresh.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        refresh.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        refresh.addTarget(self, action: #selector(rightBtnAction(_:)), for: .touchUpInside)
        let item = UIBarButtonItem(customView: refresh)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
        
        mpaview.layer.cornerRadius = 10
        mpaview.layer.borderWidth = 3
        mpaview.layer.borderColor = UIColor(named: "orange")?.cgColor
    }
    
    @objc func rightBtnAction(_ sender: UIButton) {
        manager.requestWhenInUseAuthorization()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.startUpdatingLocation()
    }
    
    @IBAction func btnshare(_ sender: Any) {
        let textToShare = [latitude, logitutde]
        let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
        activityViewController.popoverPresentationController?.sourceView = self.view
        activityViewController.excludedActivityTypes = [ UIActivity.ActivityType.airDrop, UIActivity.ActivityType.postToFacebook ]
        self.present(activityViewController, animated: true, completion: nil)
    }
}

extension LocationViewController : CLLocationManagerDelegate {
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        manager.requestWhenInUseAuthorization()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.startUpdatingLocation()
    }
    
    func reduce(_ location: CLLocation) {
        let coordinate = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        
        latitude = String(location.coordinate.latitude)
        logitutde = String(location.coordinate.longitude)
        
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let regino = MKCoordinateRegion(center: coordinate, span: span)
        
        mpaview.setRegion(regino, animated: true)
        
        let pin = MKPointAnnotation()
        pin.coordinate = coordinate
        mpaview.addAnnotation(pin)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let locations = locations.first {
            manager.stopUpdatingLocation()
            reduce(locations)
        }
    }
}
