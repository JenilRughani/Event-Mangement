//
//  StarSelectionViewController.swift
//  DateDotEventLensApp
//
//   
//

import UIKit

var arrOfStarEvent: [EventView] = []
var arrOfStarTask: [TaskView] = []

class StarSelectionViewController: UIViewController {
    @IBOutlet weak var viewbg: UIView!
    @IBOutlet weak var viewEvent: UIView!
    @IBOutlet weak var viewTask: UIView!
    @IBOutlet weak var btnEvent: UIButton!
    @IBOutlet weak var btnTask: UIButton!
    @IBOutlet weak var viewTab: UIView!
    
    var pageController = UIPageViewController()
    var index: Int = 0
    var indexPage: Int = 0
    var pageViewConreollerCount: Int = 0
    
    var arrOfVC: [UIViewController] = [
        UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "StarEventsViewController"),
        UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "StarTaskViewController"),
    ]
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let data = UserDefaults.standard.data(forKey: "arrOfStarEvent") {
            arrOfStarEvent = try! PropertyListDecoder().decode([EventView].self, from: data)
        }
        if let data = UserDefaults.standard.data(forKey: "arrOfStarTask") {
            arrOfStarTask = try! PropertyListDecoder().decode([TaskView].self, from: data)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Star Event"
        self.navigationItem.hidesBackButton = true
        
        pageVC()
        selectionTab()
        
        viewCapsulte(viewEvent)
        viewCapsulte(viewTask)
        
        btnEvent.tintColor = UIColor.white
        btnTask.tintColor = UIColor.black
    }
    
    func selectionTab() {
        switch indexPage {
        case 0:
            title = "Star Event"
            viewEvent.backgroundColor = UIColor(named: "orange")
            viewTask.backgroundColor = .clear
            
            btnEvent.tintColor = UIColor.white
            btnTask.tintColor = UIColor.black
            
        case 1:
            title = "Star Task"
            viewEvent.backgroundColor = UIColor.clear
            viewTask.backgroundColor = UIColor(named: "orange")
            
            btnEvent.tintColor = UIColor.black
            btnTask.tintColor = UIColor.white
            
        default:
            break
        }
    }
    
    func pageVC() {
        pageController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        pageController.view.backgroundColor = .clear
        pageController.view.frame = viewbg.bounds
        viewbg.addSubview(pageController.view)
        addChild(pageController)
        pageController.didMove(toParent: self)
        pageController.delegate = self
        pageController.dataSource = self
        pageController.setViewControllers([arrOfVC[0]], direction: .forward, animated: false, completion: nil)
        selectionTab()
    }
    
    func shadowView(_ view: UIView) {
        view.layer.shadowColor = UIColor.black.cgColor
        view.layer.shadowOffset = CGSize(width: 3, height: 5)
        view.layer.shadowRadius = 6
        view.layer.shadowOpacity = 0.5
        view.layer.cornerRadius = 10
    }
    
    func removeShadowView(_ view: UIView) {
        view.layer.shadowColor = UIColor.clear.cgColor
        view.layer.shadowOffset = CGSize(width: 0, height: 0)
        view.layer.shadowRadius = 0
        view.layer.shadowOpacity = 0
        view.layer.cornerRadius = 0
    }
    
    @IBAction func btnEvent(_ sender: Any) {
        title = "Star Event"
        index = 0
        indexPage = index
        selectionTab()
        pageController.setViewControllers([arrOfVC[index]], direction: pageViewConreollerCount <= indexPage ? .forward : .reverse, animated: true, completion: nil)
        pageViewConreollerCount = index
    }
    
    @IBAction func btnTask(_ sender: Any) {
        title = "Star Task"
        index = 1
        indexPage = index
        selectionTab()
        pageController.setViewControllers([arrOfVC[index]], direction: pageViewConreollerCount <= indexPage ? .forward : .reverse, animated: true, completion: nil)
        pageViewConreollerCount = index
    }
}

extension StarSelectionViewController: UIPageViewControllerDelegate, UIPageViewControllerDataSource {
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        guard let page = arrOfVC.firstIndex(of: viewController), 0 < page else {
            return nil
        }
       
        let before = page - 1
        return arrOfVC[before]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let page = arrOfVC.firstIndex(of: viewController), (arrOfVC.count-1) > page else {
            return nil
        }
       
        let after = page + 1
        return arrOfVC[after]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        selectionTab()
    }
}
