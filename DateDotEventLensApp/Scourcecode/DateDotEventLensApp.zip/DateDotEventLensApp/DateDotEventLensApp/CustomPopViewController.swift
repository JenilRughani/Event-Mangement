//
//  CustomPopViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

enum OpenState {
    case Translate
    case QR
    case Converter
    case Area
}

protocol BackOpenVc {
    func openVc(state: OpenState)
}

class CustomPopViewController: UIViewController {
    @IBOutlet weak var viewbg: UIView!
    @IBOutlet weak var btnEvent: UIButton!
    @IBOutlet weak var btnTask: UIButton!
    @IBOutlet weak var btnReminder: UIButton!
    @IBOutlet weak var btnBdReminder: UIButton!
    
    var delegate: BackOpenVc!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        
        viewbg.layer.cornerRadius = 10
        btnTask.layer.cornerRadius = 10
        btnEvent.layer.cornerRadius = 10
        btnReminder.layer.cornerRadius = 10
        btnBdReminder.layer.cornerRadius = 10
    }
    
    @IBAction func btnEvent(_ sender: Any) {
        self.dismiss(animated: true)
        delegate.openVc(state: .Translate)
    }
    
    @IBAction func btnTask(_ sender: Any) {
        self.dismiss(animated: true)
        delegate.openVc(state: .QR)
    }
    
    @IBAction func btnReminder(_ sender: Any) {
        self.dismiss(animated: true)
        delegate.openVc(state: .Converter)
    }
    
    @IBAction func btnBd(_ sender: Any) {
        self.dismiss(animated: true)
        delegate.openVc(state: .Area)
    }
    
    @IBAction func btnClsoe(_ sender: Any) {
        self.dismiss(animated: true)
    }
}
