//
//  DisplayREminderViewController.swift
//  DateDotEventLensApp
//
//  
//

import UIKit

struct ReminderView: Codable {
    var title: String
    var message: String
    var date: String
}

var arrOfBdReminde: [ReminderView] = []
var arrOfReminde: [ReminderView] = []

class ReminderCell: UITableViewCell {
    @IBOutlet weak var viewbg: UIView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblTime: UILabel!
    @IBOutlet weak var lblMEssage: UILabel!
    
}

class DisplayREminderViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    
    var isBDReminder: Bool = false
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let data = UserDefaults.standard.data(forKey: "arrOfReminde") {
            arrOfReminde = try! PropertyListDecoder().decode([ReminderView].self, from: data)
            tableView.reloadData()
        }
        
        if let data = UserDefaults.standard.data(forKey: "arrOfBdReminde") {
            arrOfBdReminde = try! PropertyListDecoder().decode([ReminderView].self, from: data)
            tableView.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = isBDReminder ? "BirthDates" : "Reminder"
        self.navigationItem.hidesBackButton = true
        
        leftNavVC()
        let add = UIButton(type: .custom)
        if #available(iOS 13.0, *) {
            add.setImage(UIImage(systemName: "plus"), for: .normal)
        } else {
            // Fallback on earlier versions
        }
        add.setTitle("Reminder", for: .normal)
        add.tintColor = .black
        add.setTitleColor(.black, for: .normal)
        add.titleLabel?.font = UIFont.systemFont(ofSize: 18, weight: .semibold)
        add.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        add.addTarget(self, action: #selector(rightBtnAction(_:)), for: .touchUpInside)
        let item = UIBarButtonItem(customView: add)
        self.navigationItem.setRightBarButtonItems([item], animated: true)
        
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    @objc func rightBtnAction(_ sender: UIButton) {
        let add = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "AddReminderViewController") as! AddReminderViewController
        add.isBdReminder = isBDReminder
        self.navigationController?.pushViewController(add, animated: true)
    }
}

extension DisplayREminderViewController : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        if isBDReminder {
            arrOfBdReminde.isEmpty ? tableView.setEmptyDataImage() : tableView.restoreEmptyDataImage()
        } else {
            arrOfReminde.isEmpty ? tableView.setEmptyDataImage() : tableView.restoreEmptyDataImage()
        }
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return isBDReminder ? arrOfBdReminde.count : arrOfReminde.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ReminderCell", for: indexPath) as! ReminderCell
        
        viewsShadowApply(cell.viewbg)
        
        if isBDReminder {
            cell.lblTime.text = arrOfBdReminde[indexPath.row].date
            cell.lblTitle.text = arrOfBdReminde[indexPath.row].title
            cell.lblMEssage.text = arrOfBdReminde[indexPath.row].message
            if #available(iOS 13.0, *) {
                cell.img.image = UIImage(named: "birthday-cake")
            } else {
                // Fallback on earlier versions
            }
        } else {
            cell.lblTime.text = arrOfReminde[indexPath.row].date
            cell.lblTitle.text = arrOfReminde[indexPath.row].title
            cell.lblMEssage.text = arrOfReminde[indexPath.row].message
            if #available(iOS 13.0, *) {
                cell.img.image = UIImage(systemName: "bell.fill")
            } else {
                // Fallback on earlier versions
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        tableView.beginUpdates()
        if isBDReminder {
            arrOfBdReminde.remove(at: indexPath.row)
        } else {
            arrOfReminde.remove(at: indexPath.row)
        }
        tableView.deleteRows(at: [indexPath], with: .fade)
        
        if isBDReminder {
            if let data = try? PropertyListEncoder().encode(arrOfBdReminde) {
                UserDefaults.standard.set(data, forKey: "arrOfBdReminde")
            }
        } else {
            if let data = try? PropertyListEncoder().encode(arrOfReminde) {
                UserDefaults.standard.set(data, forKey: "arrOfReminde")
            }
        }
        
        tableView.endUpdates()
    }
}

